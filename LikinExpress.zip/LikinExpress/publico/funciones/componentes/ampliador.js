class Ampliador {
    constructor(contenedor) {
        this.contenedor = contenedor;
        this.deslizador = contenedor.querySelector('div:nth-of-type(1)');
        this.lente = contenedor.querySelector('div:nth-of-type(2)');
        this.previaContenedor = contenedor.querySelector('div:nth-of-type(3)');
        this.previas = contenedor.querySelectorAll('div:nth-of-type(3) > div');
        this.miniaturas = contenedor.querySelectorAll('div:nth-of-type(4) > img');
        this.botones = contenedor.querySelectorAll('div:nth-of-type(5) > button');


        this.indice = 0;
        this.zoom = 0;

        this.iniciarLente();
        this.iniciarCambioImagen();
        this.iniciarMiniaturas();
        this.iniciarAcercamiento();
    }

    actualizarImagenActiva() { 
        this.previaContenedor.querySelectorAll('img').forEach(img => img.classList.remove('activo'));

        const imagenActual = this.previas[this.indice].querySelectorAll('img')[this.zoom]; imagenActual.classList.add('activo'); 
    }

    iniciarLente() {
        this.contenedor.addEventListener('mousemove', this.moverLente.bind(this));
        this.contenedor.addEventListener('mouseleave', () => {
            this.lente.classList.remove('activo');
            this.previaContenedor.classList.remove('activo');
        });
        this.contenedor.addEventListener('mouseenter', () => {
            this.lente.classList.add('activo');
            this.previaContenedor.classList.add('activo');
        });
    }

    moverLente(evento) {
        const rect = this.deslizador.getBoundingClientRect();

        let x = evento.clientX - rect.left - (this.lente.offsetWidth / 2);
        let y = evento.clientY - rect.top - (this.lente.offsetHeight / 2);

        x = Math.max(0, Math.min(x, rect.width - this.lente.offsetWidth));
        y = Math.max(0, Math.min(y, rect.height - this.lente.offsetHeight));

        this.lente.style.left = `${x}px`;
        this.lente.style.top = `${y}px`;

        this.actualizarVistaPrevia(x, y);
    }
    iniciarMiniaturas() {
        this.miniaturas.forEach((miniatura, indice) => {
            miniatura.addEventListener('mouseover', () => {
                const objetivoDesplazamiento = indice * this.deslizador.clientWidth;

                this.deslizador.scrollTo({
                    left: objetivoDesplazamiento,
                    behavior: 'smooth',
                });

            });
        });
    }
    iniciarCambioImagen() {
        this.deslizador.addEventListener('scroll', () => {
            const desplazamientoIzquierda = this.deslizador.scrollLeft;
            const anchoImagen = this.deslizador.clientWidth;
            this.indice = Math.round(desplazamientoIzquierda / anchoImagen); 

            this.actualizarImagenActiva();
        });
    }
    iniciarAcercamiento() {
        this.botones.forEach((boton, index) => {
            boton.addEventListener('click', () => {
                this.botones.forEach(btn => btn.classList.remove('activo'));
                
                if (index === 0) {
                    this.zoom = 1;
                    this.contenedor.classList.add('x4');
                } else if (index === 1) {
                    this.zoom = 0;
                    this.contenedor.classList.remove('x4');
                }
                boton.classList.add('activo');
    
                this.actualizarImagenActiva();
                this.actualizarVistaPrevia(this.lente.offsetLeft, this.lente.offsetTop);
            });
        });
    }
    
    
    actualizarVistaPrevia(x, y) {
        const previa = this.previas[this.indice].querySelectorAll('img')[this.zoom]; 

        const acercamientoFactorX = previa.clientWidth / this.deslizador.clientWidth;
        const acercamientoFactorY = previa.clientHeight / this.deslizador.clientHeight;

        const compensacionX = x * acercamientoFactorX;
        const compensacionY = y * acercamientoFactorY;

        previa.style.left = `-${compensacionX}px`;
        previa.style.top = `-${compensacionY}px`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const contenedorAmpliador = document.querySelector('.ampliador');
    new Ampliador(contenedorAmpliador);
});
